package day04;

public class Demo5 {

	public static void main(String[] args) {
		//integral 
		byte a=10;
		short b=10;
		int c=30;
		long d=40;

		//floating-point
		float e1=10.34f;
		float e2=10.34F;
		
		double f=10.43;
		//non-numerics
		boolean g=true;
		boolean h=false;
		char i='A';
		char j= '0';
		char k='&';
		char l=' ';
		
		System.out.println(a);
		
		String s="ABC";
		System.out.println(s);
		
	}

}
