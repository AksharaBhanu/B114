package day04;

public class Demo4 {

	public static void main(String[] args) {
		int i;//variable
		i=10;
		System.out.println(i);//10
		i=20;
		System.out.println(i);//20
		i=30;
		System.out.println(i);//30
		
		final int j;//constant
		j=10;
		System.out.println(j);
//		j=20;
		
		final String name="Akshara Training";
		System.out.println(name);

	}

}
