package day04;

public class Demo6 {

	public static void main(String[] args) {
		int a=10;
		int b=+10;
		int c=-10;
		
		System.out.println(a);//10
		System.out.println(b);//10
		System.out.println(c);//-10
		
		
		
	}

}
