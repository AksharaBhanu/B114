package day04;

public class Demo3 {

	public static void main(String[] args) {
		//no keywords
		
		int myclass;
//		int class;
		
		//can contain only a-z A-Z 0-9 _ $
		
		int a;
		int B;
		int $;
		int aA_$;
		int abc;
		int ABC;
		int E1231;
		int _Emp;
		
//		int 123;
//		int _;
//		int 10;

		//it should not start with a digit
		
		//CS
		
		int p;
		int P;
		
		//no max limit
		int this_is_my_bank_account_number_which_i_share_it;


	}

}
