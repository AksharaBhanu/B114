package day04;

public class Demo1 {

	public static void main(String[] args) {
		int a=10;
		String name="Bhanu";
		
		System.out.println("name");
		System.out.println(name);
		System.out.println(a);
		
	}

}
