package day03;

public class Demo5 {

	public static void main(String[] args) {
		int x=10,y=20,z=30;
		System.out.println (  x   +   " "+y+" "+z);
		System.out.println(x+","+y+","+z);
		String s=",";
		System.out.println(x+s+y+s+z);
	}

}
