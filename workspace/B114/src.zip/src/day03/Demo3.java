package day03;

public class Demo3 {

	public static void main(String[] args) {
		
		String name="Bhanu Prakash";//declaration

		System.out.println(name);

		
		System.out.println(name);

		
		
		System.out.println(name);

		
		
		System.out.println(name);
	}

}
