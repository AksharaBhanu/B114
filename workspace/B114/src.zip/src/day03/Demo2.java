package day03;


/*This is
 * multi line
 * comment
 * 
 * 
 * 
 * 
 */
public class Demo2 {

	public static void main(String[] args) {
		//hi
		System.out.println("Bhanu");
		//this is single line comment

	}

}
