package day03;

public class Demo4 {
//1 declaration---> 2initialization--> utilization
	public static void main(String[] args) {

		int a;//declaration--creating a variable
		
		a=10;//initialization-->assigning a value
		
		System.out.println(a);//value of a --> 10//utilization
		
		System.out.println("a");//a
		
		int b=20;//declaration + initialization
		System.out.println(b);
		
		int x=10,y=20,z=30;
		System.out.println(x);
		System.out.println(y);
		System.out.println(z);

	}

}
