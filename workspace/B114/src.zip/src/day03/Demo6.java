package day03;

public class Demo6 {

	public static void main(String[] args) {
		
		System.out.println("Bhanu");
		
		System.out.println("*Bhanu*");
		
//		System.out.println("*Bhanu@123*&*&^&^*%&$^#@%");
		
		System.out.println("'Bhanu'");
		System.out.println("\"Bhanu\"");
		
		System.out.println("Chandra");
		System.out.println("\"Ravi\"");
		
		System.out.println("Chandra");
		System.out.println("'Bhanu'");
		System.out.println("\"Ravi\"");
		
	}

}
